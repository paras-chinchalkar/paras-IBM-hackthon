import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster, toast } from 'react-hot-toast';
import { Settings } from 'lucide-react';
import Header from './components/Header';
import FeatureCard from './components/FeatureCard';
import InputForm from './components/InputForm';
import LoadingSpinner from './components/LoadingSpinner';
import ResultDisplay from './components/ResultDisplay';
import ConfigurationModal from './components/ConfigurationModal';
import { GraniteService } from './services/graniteService';
import { CodeRequest, CodeResponse } from './types';

const features = [
  {
    id: 'generate',
    title: 'Generate Code',
    description: 'Create functions, classes, and complete code snippets from natural language descriptions.',
    icon: 'code',
    color: 'bg-green-500'
  },
  {
    id: 'explain',
    title: 'Explain Code',
    description: 'Get detailed explanations of complex code structures and algorithms.',
    icon: 'explain',
    color: 'bg-blue-500'
  },
  {
    id: 'debug',
    title: 'Debug & Optimize',
    description: 'Identify bugs, performance issues, and get optimization suggestions.',
    icon: 'debug',
    color: 'bg-red-500'
  },
  {
    id: 'convert',
    title: 'Convert Languages',
    description: 'Transform code between different programming languages while preserving functionality.',
    icon: 'convert',
    color: 'bg-purple-500'
  },
  {
    id: 'document',
    title: 'Generate Docs',
    description: 'Create comprehensive documentation with examples and best practices.',
    icon: 'document',
    color: 'bg-orange-500'
  }
];

function App() {
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CodeResponse | null>(null);
  const [showConfig, setShowConfig] = useState(false);
  const [isConfigured, setIsConfigured] = useState(false);

  useEffect(() => {
    // Check if configuration exists
    setIsConfigured(GraniteService.isConfigured());
  }, []);

  const handleFeatureSelect = (featureId: string) => {
    // Allow access to features without requiring configuration upfront
    setSelectedFeature(featureId);
    setResult(null);
  };

  const handleFormSubmit = async (data: CodeRequest) => {
    // Check configuration only when actually trying to process a request
    if (!GraniteService.isConfigured()) {
      toast.error('Please configure your IBM Granite API credentials first');
      setShowConfig(true);
      return;
    }

    setLoading(true);
    setResult(null);
    
    try {
      const response = await GraniteService.processRequest(data);
      setResult(response);
      toast.success('Code processed successfully with IBM Granite!');
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to process request. Please try again.';
      toast.error(errorMessage);
      console.error('Error processing request:', error);
      
      // If authentication error, show config modal
      if (errorMessage.includes('Authentication') || errorMessage.includes('API key') || errorMessage.includes('credentials')) {
        setShowConfig(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleBackToFeatures = () => {
    setSelectedFeature(null);
    setResult(null);
  };

  const handleConfigSave = (config: { apiKey: string; projectId: string }) => {
    // Store in localStorage for demo purposes
    // In production, use secure environment variables
    localStorage.setItem('ibm_api_key', config.apiKey);
    localStorage.setItem('ibm_project_id', config.projectId);
    setIsConfigured(true);
    toast.success('IBM Granite configuration saved successfully!');
  };

  return (
    <div className="min-h-screen bg-ibm-gray-10">
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#161616',
            color: '#ffffff',
            fontFamily: 'IBM Plex Sans'
          }
        }}
      />
      
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Configuration Button */}
        <div className="flex justify-end mb-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowConfig(true)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-ibm transition-colors ${
              isConfigured 
                ? 'bg-green-100 text-green-800 border border-green-200' 
                : 'bg-yellow-100 text-yellow-800 border border-yellow-200'
            }`}
          >
            <Settings className="h-4 w-4" />
            <span>{isConfigured ? 'Configured' : 'Configure IBM Granite'}</span>
          </motion.button>
        </div>

        <AnimatePresence mode="wait">
          {!selectedFeature ? (
            <motion.div
              key="features"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="text-center">
                <motion.h2 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-3xl font-bold text-ibm-gray-100 font-ibm mb-4"
                >
                  AI-Powered Development Assistant
                </motion.h2>
                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="text-lg text-ibm-gray-70 max-w-3xl mx-auto leading-relaxed"
                >
                  Harness the power of IBM's Granite Code models to accelerate your development workflow. 
                  Generate, explain, debug, convert, and document code with enterprise-grade AI assistance.
                </motion.p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {features.map((feature, index) => (
                  <motion.div
                    key={feature.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <FeatureCard
                      title={feature.title}
                      description={feature.description}
                      icon={feature.icon}
                      color={feature.color}
                      onClick={() => handleFeatureSelect(feature.id)}
                    />
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="bg-white rounded-lg border border-ibm-gray-20 p-6 text-center"
              >
                <h3 className="text-lg font-semibold text-ibm-gray-100 font-ibm mb-2">
                  Built for IBM TechXchange
                </h3>
                <p className="text-ibm-gray-70">
                  Showcasing the capabilities of IBM Granite Code models in a production-ready development environment.
                </p>
                {!isConfigured && (
                  <p className="text-sm text-yellow-600 mt-2">
                    Click on any feature above to get started. You'll be prompted to configure your IBM Granite API credentials when needed.
                  </p>
                )}
              </motion.div>
            </motion.div>
          ) : (
            <motion.div
              key="form"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleBackToFeatures}
                  className="text-ibm-blue hover:text-ibm-blue-dark font-semibold font-ibm"
                >
                  ← Back to Features
                </motion.button>
                
                <div className="text-right">
                  <h2 className="text-2xl font-bold text-ibm-gray-100 font-ibm">
                    {features.find(f => f.id === selectedFeature)?.title}
                  </h2>
                  <p className="text-ibm-gray-70">
                    Powered by IBM Granite Code
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <InputForm
                    type={selectedFeature}
                    onSubmit={handleFormSubmit}
                    loading={loading}
                  />
                </div>

                <div className="bg-white rounded-lg border border-ibm-gray-20 p-6">
                  <h3 className="text-lg font-semibold text-ibm-gray-100 font-ibm mb-4">
                    Result
                  </h3>
                  
                  {loading && <LoadingSpinner />}
                  
                  {result && !loading && (
                    <ResultDisplay result={result} type={selectedFeature} />
                  )}
                  
                  {!result && !loading && (
                    <div className="text-center py-12 text-ibm-gray-50">
                      <p>Results will appear here after processing</p>
                      {!isConfigured && (
                        <p className="text-sm text-yellow-600 mt-2">
                          You'll be prompted to configure your IBM Granite API credentials when you submit your request.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <ConfigurationModal
        isOpen={showConfig}
        onClose={() => setShowConfig(false)}
        onSave={handleConfigSave}
      />
    </div>
  );
}

export default App;