import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Code, ArrowRight } from 'lucide-react';
import CodeEditor from './CodeEditor';

interface InputFormProps {
  type: string;
  onSubmit: (data: any) => void;
  loading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ type, onSubmit, loading }) => {
  const [code, setCode] = useState('');
  const [prompt, setPrompt] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [targetLanguage, setTargetLanguage] = useState('python');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const data = {
      type,
      code: code.trim(),
      prompt: prompt.trim(),
      language,
      targetLanguage,
      description: prompt.trim()
    };

    onSubmit(data);
  };

  const getFormTitle = () => {
    switch (type) {
      case 'generate':
        return 'Generate Code';
      case 'explain':
        return 'Explain Code';
      case 'debug':
        return 'Debug Code';
      case 'convert':
        return 'Convert Code';
      case 'document':
        return 'Generate Documentation';
      default:
        return 'Process Code';
    }
  };

  const getPlaceholder = () => {
    switch (type) {
      case 'generate':
        return 'Describe what you want to build (e.g., "Create a fibonacci function")';
      case 'explain':
        return 'Ask about specific aspects of the code you want explained';
      case 'debug':
        return 'Describe the issue you\'re experiencing';
      case 'convert':
        return 'Any specific requirements for the conversion';
      case 'document':
        return 'Any specific documentation requirements';
      default:
        return 'Enter your request...';
    }
  };

  const needsCodeInput = ['explain', 'debug', 'convert', 'document'].includes(type);
  const needsPrompt = ['generate', 'explain', 'debug', 'convert', 'document'].includes(type);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg border border-ibm-gray-20 p-6"
    >
      <div className="flex items-center space-x-2 mb-6">
        <Code className="h-5 w-5 text-ibm-blue" />
        <h3 className="text-lg font-semibold text-ibm-gray-100 font-ibm">
          {getFormTitle()}
        </h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {needsPrompt && (
          <div>
            <label className="block text-sm font-medium text-ibm-gray-100 mb-2 font-ibm">
              {type === 'generate' ? 'What do you want to build?' : 'Description'}
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={getPlaceholder()}
              className="w-full h-24 p-3 border border-ibm-gray-30 rounded-lg focus:border-ibm-blue focus:outline-none resize-none font-ibm"
              required={type === 'generate'}
            />
          </div>
        )}

        {needsCodeInput && (
          <div>
            <label className="block text-sm font-medium text-ibm-gray-100 mb-2 font-ibm">
              Code Input
            </label>
            <CodeEditor
              code={code}
              language={language}
              onChange={setCode}
              placeholder="Paste your code here..."
            />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-ibm-gray-100 mb-2 font-ibm">
              {type === 'convert' ? 'Source Language' : 'Language'}
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full p-3 border border-ibm-gray-30 rounded-lg focus:border-ibm-blue focus:outline-none font-ibm"
            >
              <option value="javascript">JavaScript</option>
              <option value="python">Python</option>
              <option value="typescript">TypeScript</option>
              <option value="java">Java</option>
              <option value="cpp">C++</option>
              <option value="go">Go</option>
            </select>
          </div>

          {type === 'convert' && (
            <div>
              <label className="block text-sm font-medium text-ibm-gray-100 mb-2 font-ibm">
                Target Language
              </label>
              <select
                value={targetLanguage}
                onChange={(e) => setTargetLanguage(e.target.value)}
                className="w-full p-3 border border-ibm-gray-30 rounded-lg focus:border-ibm-blue focus:outline-none font-ibm"
              >
                <option value="python">Python</option>
                <option value="javascript">JavaScript</option>
                <option value="typescript">TypeScript</option>
                <option value="java">Java</option>
                <option value="cpp">C++</option>
                <option value="go">Go</option>
              </select>
            </div>
          )}
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          type="submit"
          disabled={loading || (type === 'generate' && !prompt.trim()) || (needsCodeInput && !code.trim())}
          className="w-full bg-ibm-blue hover:bg-ibm-blue-dark disabled:bg-ibm-gray-30 text-white font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2 font-ibm"
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
              <span>Processing...</span>
            </>
          ) : (
            <>
              <Send className="h-4 w-4" />
              <span>Process with Granite</span>
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </motion.button>
      </form>
    </motion.div>
  );
};

export default InputForm;