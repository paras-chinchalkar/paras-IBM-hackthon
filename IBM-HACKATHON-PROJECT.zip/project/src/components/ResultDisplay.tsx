import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Lightbulb, AlertCircle } from 'lucide-react';
import CodeEditor from './CodeEditor';
import { CodeResponse } from '../types';

interface ResultDisplayProps {
  result: CodeResponse;
  type: string;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, type }) => {
  const getTypeIcon = () => {
    switch (type) {
      case 'generate':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'explain':
        return <Lightbulb className="h-5 w-5 text-yellow-500" />;
      case 'debug':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'convert':
        return <CheckCircle className="h-5 w-5 text-blue-500" />;
      case 'document':
        return <CheckCircle className="h-5 w-5 text-purple-500" />;
      default:
        return <CheckCircle className="h-5 w-5 text-ibm-blue" />;
    }
  };

  const getTypeTitle = () => {
    switch (type) {
      case 'generate':
        return 'Code Generated';
      case 'explain':
        return 'Code Explanation';
      case 'debug':
        return 'Debug Results';
      case 'convert':
        return 'Code Converted';
      case 'document':
        return 'Documentation Generated';
      default:
        return 'Result';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center space-x-2 mb-4">
        {getTypeIcon()}
        <h3 className="text-lg font-semibold text-ibm-gray-100 font-ibm">
          {getTypeTitle()}
        </h3>
      </div>

      <div className="bg-white rounded-lg border border-ibm-gray-20 overflow-hidden">
        <CodeEditor
          code={result.result}
          language={result.language || 'javascript'}
          readOnly
        />
      </div>

      {result.explanation && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-ibm-blue/5 border border-ibm-blue/20 rounded-lg p-4"
        >
          <h4 className="font-semibold text-ibm-gray-100 mb-2 font-ibm">
            Explanation
          </h4>
          <p className="text-ibm-gray-70 text-sm leading-relaxed">
            {result.explanation}
          </p>
        </motion.div>
      )}

      {result.suggestions && result.suggestions.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="bg-yellow-50 border border-yellow-200 rounded-lg p-4"
        >
          <h4 className="font-semibold text-ibm-gray-100 mb-3 font-ibm flex items-center">
            <Lightbulb className="h-4 w-4 text-yellow-500 mr-2" />
            Suggestions
          </h4>
          <ul className="space-y-2">
            {result.suggestions.map((suggestion, index) => (
              <li key={index} className="text-ibm-gray-70 text-sm flex items-start">
                <span className="text-yellow-500 mr-2">•</span>
                {suggestion}
              </li>
            ))}
          </ul>
        </motion.div>
      )}
    </motion.div>
  );
};

export default ResultDisplay;