import React from 'react';
import { motion } from 'framer-motion';
import { 
  Code, 
  FileText, 
  Bug, 
  RefreshCw, 
  BookOpen 
} from 'lucide-react';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: string;
  color: string;
  onClick: () => void;
  isActive?: boolean;
}

const iconMap = {
  code: Code,
  explain: FileText,
  debug: Bug,
  convert: RefreshCw,
  document: BookOpen
};

const FeatureCard: React.FC<FeatureCardProps> = ({ 
  title, 
  description, 
  icon, 
  color, 
  onClick, 
  isActive = false 
}) => {
  const IconComponent = iconMap[icon as keyof typeof iconMap] || Code;
  
  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      className={`
        p-6 rounded-xl border-2 cursor-pointer transition-all duration-300
        ${isActive 
          ? 'border-ibm-blue bg-ibm-blue/5 shadow-lg' 
          : 'border-ibm-gray-20 bg-white hover:border-ibm-blue-light hover:shadow-md'
        }
      `}
      onClick={onClick}
    >
      <div className="flex items-start space-x-4">
        <div className={`p-3 rounded-lg ${color}`}>
          <IconComponent className="h-6 w-6 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-ibm-gray-100 font-ibm mb-2">
            {title}
          </h3>
          <p className="text-ibm-gray-70 text-sm leading-relaxed">
            {description}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default FeatureCard;