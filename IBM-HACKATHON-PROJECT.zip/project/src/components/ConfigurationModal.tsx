import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Settings, AlertCircle, CheckCircle } from 'lucide-react';

interface ConfigurationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (config: { apiKey: string; projectId: string }) => void;
}

const ConfigurationModal: React.FC<ConfigurationModalProps> = ({ isOpen, onClose, onSave }) => {
  const [apiKey, setApiKey] = useState('');
  const [projectId, setProjectId] = useState('');
  const [isValid, setIsValid] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (apiKey.trim() && projectId.trim()) {
      onSave({ apiKey: apiKey.trim(), projectId: projectId.trim() });
      onClose();
    }
  };

  const validateInputs = () => {
    const valid = apiKey.trim().length > 0 && projectId.trim().length > 0;
    setIsValid(valid);
  };

  React.useEffect(() => {
    validateInputs();
  }, [apiKey, projectId]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-lg p-6 w-full max-w-md"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <Settings className="h-5 w-5 text-ibm-blue" />
                <h2 className="text-lg font-semibold text-ibm-gray-100 font-ibm">
                  IBM Granite Configuration
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-ibm-gray-70 hover:text-ibm-gray-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <div className="flex items-start space-x-2">
                <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-blue-900 mb-1">Setup Required</h3>
                  <p className="text-sm text-blue-800">
                    To use IBM Granite Code models, you need to:
                  </p>
                  <ol className="text-sm text-blue-800 mt-2 ml-4 list-decimal">
                    <li>Create an IBM Cloud account</li>
                    <li>Set up Watson Machine Learning service</li>
                    <li>Get your API key and Project ID</li>
                  </ol>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-ibm-gray-100 mb-2 font-ibm">
                  IBM Cloud API Key
                </label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your IBM Cloud API key"
                  className="w-full p-3 border border-ibm-gray-30 rounded-lg focus:border-ibm-blue focus:outline-none font-ibm"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-ibm-gray-100 mb-2 font-ibm">
                  Watson ML Project ID
                </label>
                <input
                  type="text"
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                  placeholder="Enter your Watson ML Project ID"
                  className="w-full p-3 border border-ibm-gray-30 rounded-lg focus:border-ibm-blue focus:outline-none font-ibm"
                  required
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 px-4 py-2 border border-ibm-gray-30 text-ibm-gray-70 rounded-lg hover:bg-ibm-gray-10 transition-colors font-ibm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!isValid}
                  className="flex-1 px-4 py-2 bg-ibm-blue text-white rounded-lg hover:bg-ibm-blue-dark disabled:bg-ibm-gray-30 transition-colors font-ibm flex items-center justify-center space-x-2"
                >
                  {isValid && <CheckCircle className="h-4 w-4" />}
                  <span>Save Configuration</span>
                </button>
              </div>
            </form>

            <div className="mt-4 text-xs text-ibm-gray-50">
              <p>
                Your credentials are stored locally and never sent to third parties.
                Visit{' '}
                <a 
                  href="https://cloud.ibm.com/docs/watson-machine-learning" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-ibm-blue hover:underline"
                >
                  IBM Cloud Documentation
                </a>{' '}
                for setup instructions.
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ConfigurationModal;