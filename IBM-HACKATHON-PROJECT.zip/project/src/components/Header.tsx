import React from 'react';
import { Code, Cpu } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-ibm-gray-20 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-ibm-blue rounded-lg">
                <Code className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-ibm-gray-100 font-ibm">
                  Granite Dev Assistant
                </h1>
                <p className="text-sm text-ibm-gray-70">Powered by IBM Granite Code</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 text-ibm-gray-70">
            <Cpu className="h-4 w-4" />
            <span className="text-sm font-ibm">AI-Powered</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;