import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface CodeEditorProps {
  code: string;
  language: string;
  readOnly?: boolean;
  onChange?: (code: string) => void;
  placeholder?: string;
}

const CodeEditor: React.FC<CodeEditorProps> = ({ 
  code, 
  language, 
  readOnly = false, 
  onChange,
  placeholder = "Enter your code here..."
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  if (readOnly) {
    return (
      <div className="relative">
        <div className="absolute top-3 right-3 z-10">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleCopy}
            className="p-2 bg-ibm-gray-90/80 hover:bg-ibm-gray-70 rounded-lg transition-colors"
          >
            <AnimatePresence mode="wait">
              {copied ? (
                <motion.div
                  key="check"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                >
                  <Check className="h-4 w-4 text-green-400" />
                </motion.div>
              ) : (
                <motion.div
                  key="copy"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                >
                  <Copy className="h-4 w-4 text-white" />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>
        </div>
        <SyntaxHighlighter
          language={language}
          style={vscDarkPlus}
          className="rounded-lg !bg-ibm-gray-100 !text-sm"
          customStyle={{
            margin: 0,
            padding: '1.5rem',
            fontSize: '14px',
            lineHeight: '1.5'
          }}
        >
          {code}
        </SyntaxHighlighter>
      </div>
    );
  }

  return (
    <div className="relative">
      <textarea
        value={code}
        onChange={(e) => onChange?.(e.target.value)}
        placeholder={placeholder}
        className="w-full h-64 p-4 bg-ibm-gray-100 text-white font-ibm-mono text-sm rounded-lg border border-ibm-gray-70 focus:border-ibm-blue focus:outline-none resize-none"
        style={{ fontFamily: 'IBM Plex Mono, monospace' }}
      />
    </div>
  );
};

export default CodeEditor;