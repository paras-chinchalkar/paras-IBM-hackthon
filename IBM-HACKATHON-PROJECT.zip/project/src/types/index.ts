export interface CodeRequest {
  type: 'generate' | 'explain' | 'debug' | 'convert' | 'document';
  code?: string;
  language?: string;
  targetLanguage?: string;
  description?: string;
  prompt?: string;
}

export interface CodeResponse {
  result: string;
  explanation?: string;
  suggestions?: string[];
  language?: string;
}

export interface ConversationMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  code?: string;
  language?: string;
  timestamp: Date;
}

export interface FeatureCard {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
}