import axios from 'axios';
import { CodeRequest, CodeResponse } from '../types';

interface GraniteAPIRequest {
  model_id: string;
  input: string;
  parameters: {
    decoding_method: string;
    max_new_tokens: number;
    temperature: number;
    top_p: number;
    repetition_penalty: number;
  };
  project_id: string;
}

interface GraniteAPIResponse {
  results: Array<{
    generated_text: string;
    generated_token_count: number;
    input_token_count: number;
    stop_reason: string;
  }>;
}

export class GraniteService {
  private static getConfig() {
    const apiKey = import.meta.env.VITE_IBM_API_KEY || localStorage.getItem('ibm_api_key');
    const projectId = import.meta.env.VITE_IBM_PROJECT_ID || localStorage.getItem('ibm_project_id');
    const apiUrl = import.meta.env.VITE_IBM_API_URL || 'https://us-south.ml.cloud.ibm.com/ml/v1/text/generation';
    const modelId = import.meta.env.VITE_GRANITE_MODEL_ID || 'ibm/granite-13b-chat-v2';

    return {
      apiKey,
      projectId,
      apiUrl,
      modelId,
      maxTokens: 2048,
      temperature: 0.1,
      topP: 0.9
    };
  }

  private static validateConfig() {
    const config = this.getConfig();
    if (!config.apiKey) {
      throw new Error('IBM API Key is required. Please configure your credentials.');
    }
    if (!config.projectId) {
      throw new Error('IBM Project ID is required. Please configure your credentials.');
    }
    return config;
  }

  private static async getAccessToken(apiKey: string): Promise<string> {
    try {
      const response = await axios.post('https://iam.cloud.ibm.com/identity/token', 
        new URLSearchParams({
          grant_type: 'urn:iam:params:oauth:grant-type:apikey',
          apikey: apiKey
        }), {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json'
          }
        }
      );
      return response.data.access_token;
    } catch (error) {
      console.error('Error getting access token:', error);
      throw new Error('Failed to authenticate with IBM Cloud. Please check your API key.');
    }
  }

  private static async callGraniteAPI(prompt: string): Promise<string> {
    try {
      const config = this.validateConfig();
      const accessToken = await this.getAccessToken(config.apiKey!);

      const requestData: GraniteAPIRequest = {
        model_id: config.modelId,
        input: prompt,
        parameters: {
          decoding_method: 'greedy',
          max_new_tokens: config.maxTokens,
          temperature: config.temperature,
          top_p: config.topP,
          repetition_penalty: 1.1
        },
        project_id: config.projectId!
      };

      const response = await axios.post<GraniteAPIResponse>(
        config.apiUrl,
        requestData,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        }
      );

      if (response.data.results && response.data.results.length > 0) {
        return response.data.results[0].generated_text;
      } else {
        throw new Error('No results returned from Granite API');
      }
    } catch (error) {
      console.error('Error calling Granite API:', error);
      if (axios.isAxiosError(error)) {
        if (error.response?.status === 401) {
          throw new Error('Authentication failed. Please check your IBM API key.');
        } else if (error.response?.status === 403) {
          throw new Error('Access denied. Please check your project permissions.');
        } else if (error.response?.status === 429) {
          throw new Error('Rate limit exceeded. Please try again later.');
        }
      }
      throw new Error('Failed to connect to IBM Granite API. Please check your configuration.');
    }
  }

  private static buildPrompt(request: CodeRequest): string {
    const basePrompts = {
      generate: `You are an expert software developer. Generate clean, efficient, and well-documented code based on the following requirements:

Requirements: ${request.prompt}
Programming Language: ${request.language || 'JavaScript'}

Please provide only the code without additional explanations:`,

      explain: `You are an expert code reviewer. Analyze and explain the following code in detail:

Code to explain:
\`\`\`${request.language || 'javascript'}
${request.code}
\`\`\`

Additional context: ${request.prompt || 'Provide a comprehensive explanation'}

Please provide a detailed explanation covering:
1. What the code does
2. How it works
3. Key concepts used
4. Potential improvements`,

      debug: `You are an expert debugger. Analyze the following code for bugs, performance issues, and improvements:

Code to debug:
\`\`\`${request.language || 'javascript'}
${request.code}
\`\`\`

Issue description: ${request.prompt || 'General debugging and optimization'}

Please provide:
1. Identified issues
2. Fixed code
3. Explanation of changes
4. Performance improvements`,

      convert: `You are an expert in multiple programming languages. Convert the following code from ${request.language} to ${request.targetLanguage}:

Source code (${request.language}):
\`\`\`${request.language}
${request.code}
\`\`\`

Requirements: ${request.prompt || 'Maintain functionality while following target language best practices'}

Please provide the converted code with equivalent functionality:`,

      document: `You are a technical documentation expert. Generate comprehensive documentation for the following code:

Code to document:
\`\`\`${request.language || 'javascript'}
${request.code}
\`\`\`

Requirements: ${request.prompt || 'Create complete documentation with examples'}

Please provide documentation including:
1. Overview and purpose
2. Parameters and return values
3. Usage examples
4. Best practices`
    };

    return basePrompts[request.type] || basePrompts.generate;
  }

  private static parseResponse(rawResponse: string, type: string): CodeResponse {
    // Clean up the response
    const cleanResponse = rawResponse.trim();
    
    // Extract code blocks if present
    const codeBlockRegex = /```[\w]*\n?([\s\S]*?)```/g;
    const codeMatches = [...cleanResponse.matchAll(codeBlockRegex)];
    
    let result = cleanResponse;
    let explanation = '';
    
    if (codeMatches.length > 0) {
      // If code blocks are found, use the first one as the main result
      result = codeMatches[0][1].trim();
      
      // Use the text outside code blocks as explanation
      explanation = cleanResponse.replace(codeBlockRegex, '').trim();
    } else if (type === 'explain' || type === 'document') {
      // For explanations and documentation, the entire response is the result
      result = cleanResponse;
    }

    return {
      result,
      explanation: explanation || undefined,
      language: type === 'document' ? 'markdown' : undefined
    };
  }

  static isConfigured(): boolean {
    const apiKey = import.meta.env.VITE_IBM_API_KEY || localStorage.getItem('ibm_api_key');
    const projectId = import.meta.env.VITE_IBM_PROJECT_ID || localStorage.getItem('ibm_project_id');
    return !!(apiKey && projectId);
  }

  static async processRequest(request: CodeRequest): Promise<CodeResponse> {
    try {
      const prompt = this.buildPrompt(request);
      const rawResponse = await this.callGraniteAPI(prompt);
      return this.parseResponse(rawResponse, request.type);
    } catch (error) {
      console.error('Error processing request:', error);
      throw error;
    }
  }
}