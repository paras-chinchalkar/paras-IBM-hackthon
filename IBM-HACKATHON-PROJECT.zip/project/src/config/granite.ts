export const graniteConfig = {
  apiKey: import.meta.env.VITE_IBM_API_KEY,
  projectId: import.meta.env.VITE_IBM_PROJECT_ID,
  apiUrl: import.meta.env.VITE_IBM_API_URL || 'https://us-south.ml.cloud.ibm.com/ml/v1/text/generation',
  modelId: import.meta.env.VITE_GRANITE_MODEL_ID || 'ibm/granite-13b-chat-v2',
  maxTokens: 2048,
  temperature: 0.1,
  topP: 0.9
};

export const validateConfig = () => {
  if (!graniteConfig.apiKey) {
    throw new Error('IBM API Key is required. Please set VITE_IBM_API_KEY in your environment variables.');
  }
  if (!graniteConfig.projectId) {
    throw new Error('IBM Project ID is required. Please set VITE_IBM_PROJECT_ID in your environment variables.');
  }
};