/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_IBM_API_KEY: string
  readonly VITE_IBM_PROJECT_ID: string
  readonly VITE_IBM_API_URL: string
  readonly VITE_GRANITE_MODEL_ID: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}