/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        border: '#e0e0e0',
        background: '#f4f4f4',
        foreground: '#161616',
        'ibm-blue': '#0f62fe',
        'ibm-blue-dark': '#0043ce',
        'ibm-blue-light': '#4589ff',
        'ibm-gray': {
          10: '#f4f4f4',
          20: '#e0e0e0',
          30: '#c6c6c6',
          50: '#8d8d8d',
          70: '#525252',
          90: '#262626',
          100: '#161616'
        }
      },
      fontFamily: {
        'ibm': ['IBM Plex Sans', 'system-ui', 'sans-serif'],
        'ibm-mono': ['IBM Plex Mono', 'monospace']
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out'
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' }
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' }
        }
      }
    },
  },
  plugins: [],
}